const presensiRecords = [
  // Kita bisa mulai dengan data contoh
  {
    userId: 456,
    nama: 'User Karyawan',
    checkIn: new Date('2025-10-14T08:05:00'),
    checkOut: new Date('2025-10-14T17:00:00')
  }
];

module.exports = presensiRecords;
