## 1. GET /api/books
![GET Books](screenshoots/MethodGet.png)

## 2. GET /api/books/:id
![GET Books by ID](screenshoots/MethodGetById.png)

## 3. POST /api/books
![POST Books](screenshoots/MethodPost.png)

## 4. PUT /api/books/:id
![PUT Books](screenshoots/MethodPut.png)

## 5. DELETE /api/books/:id
![Delete Books](screenshoots/MethodDelete.png)



## 1. GET /api/movies
![GET MOVIES](screenshoots/MethodGetMovies.png)

## 2. GET /api/movies/:id
![GET MOVIES by ID](screenshoots/MethodGetByIdMovies.png)

## 3. POST /api/MOVIES
![POST MOVIES](screenshoots/MethodPostMovies.png)

## 4. PUT /api/MOVIES/:id
![PUT MOVIES](screenshoots/MethodPutMovies.png)

## 5. DELETE /api/MOVIES/:id
![DELETE MOVIES](screenshoots/MethodDeleteMovies.png)

